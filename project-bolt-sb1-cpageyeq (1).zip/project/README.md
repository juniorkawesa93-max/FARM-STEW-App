# FARM STEW Scanner

A comprehensive document scanning app designed for NGO fieldwork. Built with React Native and Expo, featuring modern UI, offline-first operation, OCR text extraction, secure document management, and cloud synchronization.

## Features

### 🔍 Core Scanning
- Real-time edge detection and auto-capture
- Multi-page document handling
- Image enhancement presets (Auto, Color, Grayscale, B&W)
- Manual and batch scanning modes
- Perspective correction and auto-rotation

### 📱 Smart Organization
- Folder-based document management
- Tag system for categorization
- Advanced search with OCR text recognition
- Document templates and auto-naming
- Quick actions and shortcuts

### 🔒 Security & Privacy
- Biometric app lock (fingerprint/face ID)
- Local document encryption (AES)
- Privacy mode for sensitive documents
- Secure sharing and export options
- Data wipe capabilities

### ☁️ Sync & Sharing
- Offline-first architecture
- Cloud backup and synchronization
- Multiple export formats (PDF, JPEG, PNG)
- Password-protected PDF export
- Share via WhatsApp, Email, Drive, etc.

### 🎨 User Experience
- Modern, accessible UI design
- NGO-friendly color palette
- Dark mode support
- Smooth animations and micro-interactions
- Comprehensive onboarding

## Color Palette

- **Primary Green**: `#28A745` (growth/agriculture)
- **Accent Teal**: `#06B6D4` (trust/water)
- **Warm Yellow**: `#FFD54F` (hope/highlights)
- **Neutral Background**: `#FAFBFC`
- **Dark Text**: `#0F1724`

## Tech Stack

- **Framework**: React Native with Expo
- **Navigation**: Expo Router
- **UI Components**: Custom components with StyleSheet
- **Icons**: Lucide React Native
- **Camera**: Expo Camera
- **Storage**: Expo SecureStore
- **Networking**: Fetch API
- **Authentication**: Expo Local Authentication

## Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- Expo CLI (`npm install -g expo-cli`)
- Android Studio (for Android development)
- Xcode (for iOS development, macOS only)

## Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/farm-stew-scanner.git
cd farm-stew-scanner
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Use Expo Go app on your mobile device to scan the QR code, or run on emulator.

## Building APK Files

### Development Build

1. Install EAS CLI:
```bash
npm install -g eas-cli
```

2. Configure EAS:
```bash
eas build:configure
```

3. Build development APK:
```bash
eas build --platform android --profile development
```

### Production Build

1. Update app version in `app.json`

2. Build production APK:
```bash
eas build --platform android --profile production
```

3. Submit to Google Play Store (optional):
```bash
eas submit --platform android
```

## Environment Variables

Create a `.env` file in the root directory:

```env
# Supabase Configuration (optional)
EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# Sentry Error Tracking (optional)
SENTRY_DSN=your_sentry_dsn

# Firebase Configuration (optional)
EXPO_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your_firebase_project_id
```

## Project Structure

```
farm-stew-scanner/
├── app/                          # App screens and navigation
│   ├── (tabs)/                   # Tab-based screens
│   │   ├── index.tsx            # Home screen
│   │   ├── scan.tsx             # Camera/scanning screen
│   │   ├── search.tsx           # Document search
│   │   └── settings.tsx         # App settings
│   ├── _layout.tsx              # Root layout
│   └── +not-found.tsx           # 404 screen
├── components/                   # Reusable components
│   ├── DocumentViewer.tsx       # Document viewer/editor
│   └── OnboardingScreen.tsx     # App introduction
├── hooks/                        # Custom React hooks
├── assets/                       # Static assets
├── app.json                      # Expo configuration
└── package.json                  # Dependencies
```

## Features Implementation Status

✅ **Completed:**
- Core UI/UX design
- Tab navigation structure
- Home screen with document management
- Camera scanning interface
- Document search functionality
- Settings screen
- Document viewer component
- Onboarding flow

🔄 **In Development:**
- Real camera integration
- OCR text extraction
- Cloud synchronization
- Biometric authentication
- PDF generation and export

📋 **Planned:**
- Push notifications
- Offline data sync
- Advanced annotation tools
- Template recognition
- Barcode/QR scanning

## Testing

Run unit tests:
```bash
npm test
```

Run E2E tests:
```bash
npm run test:e2e
```

## Deployment

### Local Development
The app runs in Expo Go during development. Use `npm run dev` to start.

### Production Deployment
1. Build with EAS: `eas build --platform android --profile production`
2. Download APK from EAS dashboard
3. Test on physical devices
4. Submit to Google Play Store

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions:
- Create an issue in the GitHub repository
- Email: support@farmstew.org
- Documentation: [Project Wiki](https://github.com/your-org/farm-stew-scanner/wiki)

## Acknowledgments

- FARM STEW organization for project requirements
- Expo team for the excellent React Native framework
- Lucide for beautiful icons
- Community contributors

---

**FARM STEW Scanner v1.0.0** - Built with ❤️ for NGO fieldwork