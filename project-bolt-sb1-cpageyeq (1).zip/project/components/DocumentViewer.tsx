import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  Modal,
} from 'react-native';
import {
  ArrowLeft,
  Share,
  Download,
  Edit,
  Trash2,
  MoreVertical,
  ZoomIn,
  ZoomOut,
  RotateCw,
  FileText,
  Eye,
  Pen,
  Type,
  Highlighter,
} from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

interface DocumentViewerProps {
  visible: boolean;
  onClose: () => void;
  document?: {
    id: string;
    name: string;
    type: string;
    pages: number;
    size: string;
    date: string;
  };
}

export default function DocumentViewer({ visible, onClose, document }: DocumentViewerProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [showAnnotations, setShowAnnotations] = useState(false);
  const [annotationMode, setAnnotationMode] = useState<'view' | 'pen' | 'text' | 'highlight'>('view');

  const annotationTools = [
    { id: 'view', icon: Eye, label: 'View' },
    { id: 'pen', icon: Pen, label: 'Draw' },
    { id: 'text', icon: Type, label: 'Text' },
    { id: 'highlight', icon: Highlighter, label: 'Highlight' },
  ];

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  };

  const goToPreviousPage = () => {
    setCurrentPage(prev => Math.max(prev - 1, 1));
  };

  const goToNextPage = () => {
    setCurrentPage(prev => Math.min(prev + 1, document?.pages || 1));
  };

  if (!document) return null;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="fullScreen"
    >
      <SafeAreaView style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.headerButton} onPress={onClose}>
            <ArrowLeft size={24} color="#0F1724" />
          </TouchableOpacity>
          
          <View style={styles.headerTitle}>
            <Text style={styles.documentName} numberOfLines={1}>
              {document.name}
            </Text>
            <Text style={styles.documentInfo}>
              Page {currentPage} of {document.pages} • {document.type}
            </Text>
          </View>

          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.headerButton}>
              <Share size={20} color="#0F1724" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerButton}>
              <MoreVertical size={20} color="#0F1724" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Document View */}
        <ScrollView 
          style={styles.documentContainer}
          contentContainerStyle={styles.documentContent}
          maximumZoomScale={3}
          minimumZoomScale={0.5}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        >
          <View style={[
            styles.documentPage,
            {
              transform: [{ scale: zoom }],
              width: width - 40,
              height: (width - 40) * 1.4, // A4 ratio
            }
          ]}>
            <View style={styles.documentPlaceholder}>
              <FileText size={64} color="#E2E8F0" />
              <Text style={styles.documentPageNumber}>
                Page {currentPage}
              </Text>
              <Text style={styles.documentPreview}>
                Document preview would appear here
              </Text>
            </View>
          </View>
        </ScrollView>

        {/* Page Navigation */}
        {document.pages > 1 && (
          <View style={styles.pageNavigation}>
            <TouchableOpacity 
              style={[styles.pageButton, currentPage === 1 && styles.pageButtonDisabled]}
              onPress={goToPreviousPage}
              disabled={currentPage === 1}
            >
              <Text style={[styles.pageButtonText, currentPage === 1 && styles.pageButtonTextDisabled]}>
                Previous
              </Text>
            </TouchableOpacity>

            <View style={styles.pageIndicator}>
              <Text style={styles.pageIndicatorText}>
                {currentPage} / {document.pages}
              </Text>
            </View>

            <TouchableOpacity 
              style={[styles.pageButton, currentPage === document.pages && styles.pageButtonDisabled]}
              onPress={goToNextPage}
              disabled={currentPage === document.pages}
            >
              <Text style={[styles.pageButtonText, currentPage === document.pages && styles.pageButtonTextDisabled]}>
                Next
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Bottom Toolbar */}
        <View style={styles.toolbar}>
          {/* Zoom Controls */}
          <View style={styles.toolGroup}>
            <TouchableOpacity style={styles.toolButton} onPress={handleZoomOut}>
              <ZoomOut size={20} color="#0F1724" />
            </TouchableOpacity>
            <Text style={styles.zoomText}>{Math.round(zoom * 100)}%</Text>
            <TouchableOpacity style={styles.toolButton} onPress={handleZoomIn}>
              <ZoomIn size={20} color="#0F1724" />
            </TouchableOpacity>
          </View>

          {/* Annotation Toggle */}
          <TouchableOpacity 
            style={[styles.toolButton, styles.annotationToggle]}
            onPress={() => setShowAnnotations(!showAnnotations)}
          >
            <Edit size={20} color={showAnnotations ? "#28A745" : "#64748B"} />
          </TouchableOpacity>

          {/* Action Buttons */}
          <View style={styles.toolGroup}>
            <TouchableOpacity style={styles.toolButton}>
              <RotateCw size={20} color="#0F1724" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.toolButton}>
              <Download size={20} color="#0F1724" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.toolButton}>
              <Trash2 size={20} color="#EF4444" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Annotation Toolbar */}
        {showAnnotations && (
          <View style={styles.annotationToolbar}>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.annotationTools}
            >
              {annotationTools.map((tool) => (
                <TouchableOpacity
                  key={tool.id}
                  style={[
                    styles.annotationTool,
                    annotationMode === tool.id && styles.annotationToolActive
                  ]}
                  onPress={() => setAnnotationMode(tool.id as any)}
                >
                  <tool.icon 
                    size={20} 
                    color={annotationMode === tool.id ? "#FFFFFF" : "#64748B"} 
                  />
                  <Text style={[
                    styles.annotationToolText,
                    annotationMode === tool.id && styles.annotationToolTextActive
                  ]}>
                    {tool.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFBFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    flex: 1,
    paddingHorizontal: 16,
  },
  documentName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F1724',
    marginBottom: 2,
  },
  documentInfo: {
    fontSize: 12,
    color: '#64748B',
  },
  headerActions: {
    flexDirection: 'row',
  },
  documentContainer: {
    flex: 1,
  },
  documentContent: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  documentPage: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  documentPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  documentPageNumber: {
    fontSize: 18,
    fontWeight: '600',
    color: '#64748B',
    marginTop: 16,
    marginBottom: 8,
  },
  documentPreview: {
    fontSize: 14,
    color: '#94A3B8',
    textAlign: 'center',
  },
  pageNavigation: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  pageButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: '#F8FAFC',
  },
  pageButtonDisabled: {
    backgroundColor: '#F1F5F9',
  },
  pageButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#28A745',
  },
  pageButtonTextDisabled: {
    color: '#CBD5E1',
  },
  pageIndicator: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
  },
  pageIndicatorText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#64748B',
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  toolGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toolButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F8FAFC',
    justifyContent: 'center',
    alignItems: 'center',
  },
  annotationToggle: {
    backgroundColor: '#F0FDF4',
  },
  zoomText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#64748B',
    minWidth: 40,
    textAlign: 'center',
  },
  annotationToolbar: {
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    paddingVertical: 12,
  },
  annotationTools: {
    paddingHorizontal: 20,
    gap: 12,
  },
  annotationTool: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F8FAFC',
    gap: 8,
  },
  annotationToolActive: {
    backgroundColor: '#28A745',
  },
  annotationToolText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#64748B',
  },
  annotationToolTextActive: {
    color: '#FFFFFF',
  },
});