import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import {
  Scan,
  FileText,
  Shield,
  Cloud,
  ArrowRight,
  Check,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

interface OnboardingScreenProps {
  visible: boolean;
  onComplete: () => void;
}

export default function OnboardingScreen({ visible, onComplete }: OnboardingScreenProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      icon: Scan,
      title: 'Welcome to FARM STEW Scanner',
      subtitle: 'Powerful document scanning for NGO fieldwork',
      description: 'Scan, organize, and share documents with ease. Perfect for receipts, forms, reports, and training certificates.',
      color: '#28A745',
    },
    {
      icon: FileText,
      title: 'Smart Document Processing',
      subtitle: 'OCR and organization made simple',
      description: 'Automatically extract text from your scans, organize documents in folders, and search through your content.',
      color: '#06B6D4',
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      subtitle: 'Your data is protected',
      description: 'End-to-end encryption, biometric locks, and secure sharing ensure your sensitive documents stay safe.',
      color: '#8B5CF6',
    },
    {
      icon: Cloud,
      title: 'Works Offline & Online',
      subtitle: 'Sync when you can, work when you need',
      description: 'Scan and process documents offline. Sync to the cloud when connected for backup and sharing.',
      color: '#FFD54F',
    },
  ];

  const currentStepData = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      onComplete();
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  if (!visible) return null;

  return (
    <SafeAreaView style={styles.container}>
      {/* Skip Button */}
      <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Content */}
      <View style={styles.content}>
        {/* Icon */}
        <View style={[styles.iconContainer, { backgroundColor: `${currentStepData.color}20` }]}>
          <currentStepData.icon size={64} color={currentStepData.color} />
        </View>

        {/* Text Content */}
        <View style={styles.textContent}>
          <Text style={styles.title}>{currentStepData.title}</Text>
          <Text style={[styles.subtitle, { color: currentStepData.color }]}>
            {currentStepData.subtitle}
          </Text>
          <Text style={styles.description}>{currentStepData.description}</Text>
        </View>

        {/* Step Indicators */}
        <View style={styles.stepIndicators}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={[
                styles.stepDot,
                {
                  backgroundColor: index === currentStep 
                    ? currentStepData.color 
                    : '#E2E8F0',
                  width: index === currentStep ? 24 : 8,
                },
              ]}
            />
          ))}
        </View>
      </View>

      {/* Navigation */}
      <View style={styles.navigation}>
        {currentStep > 0 && (
          <TouchableOpacity style={styles.previousButton} onPress={handlePrevious}>
            <Text style={styles.previousText}>Previous</Text>
          </TouchableOpacity>
        )}
        
        <View style={styles.spacer} />

        <TouchableOpacity 
          style={[styles.nextButton, { backgroundColor: currentStepData.color }]}
          onPress={handleNext}
        >
          <Text style={styles.nextText}>
            {isLastStep ? 'Get Started' : 'Next'}
          </Text>
          {isLastStep ? (
            <Check size={16} color="#FFFFFF" />
          ) : (
            <ArrowRight size={16} color="#FFFFFF" />
          )}
        </TouchableOpacity>
      </View>

      {/* Bottom Features */}
      <View style={styles.features}>
        <View style={styles.feature}>
          <View style={styles.featureIcon}>
            <Scan size={16} color="#28A745" />
          </View>
          <Text style={styles.featureText}>Fast Scanning</Text>
        </View>
        <View style={styles.feature}>
          <View style={styles.featureIcon}>
            <FileText size={16} color="#06B6D4" />
          </View>
          <Text style={styles.featureText}>OCR Text</Text>
        </View>
        <View style={styles.feature}>
          <View style={styles.featureIcon}>
            <Shield size={16} color="#8B5CF6" />
          </View>
          <Text style={styles.featureText}>Secure</Text>
        </View>
        <View style={styles.feature}>
          <View style={styles.featureIcon}>
            <Cloud size={16} color="#FFD54F" />
          </View>
          <Text style={styles.featureText}>Cloud Sync</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFBFC',
  },
  skipButton: {
    alignSelf: 'flex-end',
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  skipText: {
    fontSize: 16,
    color: '#64748B',
    fontWeight: '500',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  textContent: {
    alignItems: 'center',
    marginBottom: 60,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#0F1724',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 24,
  },
  stepIndicators: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  stepDot: {
    height: 8,
    borderRadius: 4,
    transition: 'all 0.3s ease',
  },
  navigation: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 40,
    paddingBottom: 20,
  },
  previousButton: {
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  previousText: {
    fontSize: 16,
    color: '#64748B',
    fontWeight: '500',
  },
  spacer: {
    flex: 1,
  },
  nextButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderRadius: 24,
    gap: 8,
  },
  nextText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  features: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 40,
    paddingBottom: 40,
  },
  feature: {
    alignItems: 'center',
    gap: 8,
  },
  featureIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  featureText: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '500',
  },
});