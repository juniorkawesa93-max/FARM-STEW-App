import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  StatusBar,
  Alert,
} from 'react-native';
import {
  Camera,
  RotateCcw,
  Zap,
  ZapOff,
  Square,
  Circle,
  Scan,
  Settings,
  Grid,
  Maximize,
} from 'lucide-react-native';

const { width, height } = Dimensions.get('window');

export default function ScanScreen() {
  const [flashMode, setFlashMode] = useState(false);
  const [autoCapture, setAutoCapture] = useState(true);
  const [scanMode, setScanMode] = useState<'single' | 'batch'>('single');
  const [isScanning, setIsScanning] = useState(false);
  const [scannedPages, setScannedPages] = useState(0);

  const handleCapture = () => {
    setIsScanning(true);
    // Simulate capture animation
    setTimeout(() => {
      setIsScanning(false);
      setScannedPages(prev => prev + 1);
      
      if (scanMode === 'single') {
        Alert.alert(
          'Document Captured!',
          'Your document has been scanned successfully.',
          [
            { text: 'Scan Another', onPress: () => {} },
            { text: 'Review', onPress: () => {}, style: 'default' }
          ]
        );
      }
    }, 1000);
  };

  const toggleFlash = () => {
    setFlashMode(prev => !prev);
  };

  const toggleAutoCapture = () => {
    setAutoCapture(prev => !prev);
  };

  const switchScanMode = () => {
    setScanMode(prev => prev === 'single' ? 'batch' : 'single');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#000000" />
      
      {/* Camera View Placeholder */}
      <View style={styles.cameraContainer}>
        <View style={styles.cameraPlaceholder}>
          <Camera size={64} color="#64748B" />
          <Text style={styles.cameraText}>Camera Preview</Text>
          <Text style={styles.cameraSubtext}>Position document within the frame</Text>
          
          {/* Edge Detection Overlay */}
          <View style={styles.edgeOverlay}>
            <View style={[styles.corner, styles.topLeft]} />
            <View style={[styles.corner, styles.topRight]} />
            <View style={[styles.corner, styles.bottomLeft]} />
            <View style={[styles.corner, styles.bottomRight]} />
          </View>

          {/* Scanning Animation */}
          {isScanning && (
            <View style={styles.scanningOverlay}>
              <View style={styles.scanLine} />
              <Text style={styles.scanningText}>Scanning...</Text>
            </View>
          )}
        </View>

        {/* Top Controls */}
        <View style={styles.topControls}>
          <TouchableOpacity 
            style={[styles.controlButton, flashMode && styles.controlButtonActive]}
            onPress={toggleFlash}
          >
            {flashMode ? <Zap size={20} color="#FFD54F" /> : <ZapOff size={20} color="#FFFFFF" />}
          </TouchableOpacity>
          
          <View style={styles.topCenterControls}>
            <TouchableOpacity 
              style={[styles.modeButton, autoCapture && styles.modeButtonActive]}
              onPress={toggleAutoCapture}
            >
              <Text style={[styles.modeText, autoCapture && styles.modeTextActive]}>
                Auto
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.modeButton, scanMode === 'batch' && styles.modeButtonActive]}
              onPress={switchScanMode}
            >
              <Text style={[styles.modeText, scanMode === 'batch' && styles.modeTextActive]}>
                {scanMode === 'batch' ? 'Batch' : 'Single'}
              </Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.controlButton}>
            <Settings size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>

        {/* Bottom Controls */}
        <View style={styles.bottomControls}>
          <TouchableOpacity style={styles.galleryButton}>
            <Grid size={24} color="#FFFFFF" />
            {scannedPages > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{scannedPages}</Text>
              </View>
            )}
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.captureButton, isScanning && styles.captureButtonScanning]}
            onPress={handleCapture}
            disabled={isScanning}
          >
            <View style={styles.captureButtonInner}>
              {isScanning ? (
                <View style={styles.scanningIndicator} />
              ) : (
                <Circle size={32} color="#FFFFFF" />
              )}
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.switchButton}>
            <RotateCcw size={24} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Scan Info Bar */}
      {scanMode === 'batch' && scannedPages > 0 && (
        <View style={styles.infoBar}>
          <Text style={styles.infoText}>
            {scannedPages} page{scannedPages !== 1 ? 's' : ''} scanned
          </Text>
          <TouchableOpacity style={styles.finishButton}>
            <Text style={styles.finishButtonText}>Finish Scanning</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Guide Overlay */}
      <View style={styles.guideOverlay}>
        <View style={styles.guideBox}>
          <Maximize size={24} color="#28A745" />
          <Text style={styles.guideText}>
            {autoCapture 
              ? "Hold steady - auto capture enabled" 
              : "Tap capture button when ready"}
          </Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  cameraContainer: {
    flex: 1,
    position: 'relative',
  },
  cameraPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    position: 'relative',
  },
  cameraText: {
    fontSize: 18,
    color: '#64748B',
    marginTop: 16,
    fontWeight: '600',
  },
  cameraSubtext: {
    fontSize: 14,
    color: '#64748B',
    marginTop: 8,
    textAlign: 'center',
  },
  edgeOverlay: {
    position: 'absolute',
    width: width * 0.8,
    height: height * 0.5,
    borderWidth: 2,
    borderColor: '#28A745',
    borderStyle: 'dashed',
  },
  corner: {
    position: 'absolute',
    width: 30,
    height: 30,
    borderColor: '#28A745',
    borderWidth: 3,
  },
  topLeft: {
    top: -3,
    left: -3,
    borderRightWidth: 0,
    borderBottomWidth: 0,
  },
  topRight: {
    top: -3,
    right: -3,
    borderLeftWidth: 0,
    borderBottomWidth: 0,
  },
  bottomLeft: {
    bottom: -3,
    left: -3,
    borderRightWidth: 0,
    borderTopWidth: 0,
  },
  bottomRight: {
    bottom: -3,
    right: -3,
    borderLeftWidth: 0,
    borderTopWidth: 0,
  },
  scanningOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(40, 167, 69, 0.2)',
  },
  scanLine: {
    width: '80%',
    height: 2,
    backgroundColor: '#28A745',
    marginBottom: 16,
  },
  scanningText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  topControls: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  controlButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButtonActive: {
    backgroundColor: 'rgba(255, 213, 79, 0.3)',
  },
  topCenterControls: {
    flexDirection: 'row',
    gap: 12,
  },
  modeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modeButtonActive: {
    backgroundColor: 'rgba(40, 167, 69, 0.8)',
  },
  modeText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  modeTextActive: {
    color: '#FFFFFF',
  },
  bottomControls: {
    position: 'absolute',
    bottom: 100,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  galleryButton: {
    width: 50,
    height: 50,
    borderRadius: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  badge: {
    position: 'absolute',
    top: -8,
    right: -8,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  captureButtonScanning: {
    backgroundColor: '#28A745',
  },
  captureButtonInner: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanningIndicator: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
  },
  switchButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoBar: {
    position: 'absolute',
    bottom: 200,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  infoText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  finishButton: {
    backgroundColor: '#28A745',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
  },
  finishButtonText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  guideOverlay: {
    position: 'absolute',
    bottom: 300,
    left: 0,
    right: 0,
    alignItems: 'center',
  },
  guideBox: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  guideText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '500',
  },
});