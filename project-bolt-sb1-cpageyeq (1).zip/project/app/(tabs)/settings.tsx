import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Switch,
  Alert,
} from 'react-native';
import {
  User,
  Shield,
  Smartphone,
  Cloud,
  Globe,
  Bell,
  Download,
  Trash2,
  HelpCircle,
  Info,
  ChevronRight,
  Camera,
  Scan,
  FileText,
  Lock,
  Eye,
  EyeOff,
} from 'lucide-react-native';

export default function SettingsScreen() {
  const [biometricEnabled, setBiometricEnabled] = useState(true);
  const [autoBackup, setAutoBackup] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [ocrEnabled, setOcrEnabled] = useState(true);
  const [autoCapture, setAutoCapture] = useState(true);

  const settingsSections = [
    {
      title: 'Account',
      items: [
        {
          icon: User,
          label: 'Profile',
          subtitle: 'Manage your account information',
          onPress: () => Alert.alert('Profile', 'Profile settings coming soon'),
        },
        {
          icon: Cloud,
          label: 'Cloud Sync',
          subtitle: autoBackup ? 'Automatic backup enabled' : 'Manual backup only',
          hasSwitch: true,
          switchValue: autoBackup,
          onSwitchChange: setAutoBackup,
        },
        {
          icon: Shield,
          label: 'Security',
          subtitle: 'Manage app security settings',
          onPress: () => Alert.alert('Security', 'Security settings coming soon'),
        },
      ],
    },
    {
      title: 'Scanning',
      items: [
        {
          icon: Camera,
          label: 'Auto Capture',
          subtitle: autoCapture ? 'Documents captured automatically' : 'Manual capture mode',
          hasSwitch: true,
          switchValue: autoCapture,
          onSwitchChange: setAutoCapture,
        },
        {
          icon: Scan,
          label: 'OCR Recognition',
          subtitle: ocrEnabled ? 'Text extraction enabled' : 'OCR disabled',
          hasSwitch: true,
          switchValue: ocrEnabled,
          onSwitchChange: setOcrEnabled,
        },
        {
          icon: FileText,
          label: 'Document Quality',
          subtitle: 'Manage scan quality and compression',
          onPress: () => Alert.alert('Quality', 'Quality settings coming soon'),
        },
      ],
    },
    {
      title: 'Privacy & Security',
      items: [
        {
          icon: Lock,
          label: 'App Lock',
          subtitle: biometricEnabled ? 'Biometric lock enabled' : 'App lock disabled',
          hasSwitch: true,
          switchValue: biometricEnabled,
          onSwitchChange: setBiometricEnabled,
        },
        {
          icon: Eye,
          label: 'Privacy Mode',
          subtitle: 'Hide sensitive documents in recent list',
          onPress: () => Alert.alert('Privacy', 'Privacy mode coming soon'),
        },
        {
          icon: Trash2,
          label: 'Clear Cache',
          subtitle: 'Remove temporary files and cached data',
          onPress: () => Alert.alert(
            'Clear Cache',
            'Are you sure you want to clear the cache? This will remove temporary files.',
            [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Clear', style: 'destructive' }
            ]
          ),
        },
      ],
    },
    {
      title: 'Preferences',
      items: [
        {
          icon: Bell,
          label: 'Notifications',
          subtitle: notifications ? 'Push notifications enabled' : 'Notifications disabled',
          hasSwitch: true,
          switchValue: notifications,
          onSwitchChange: setNotifications,
        },
        {
          icon: Globe,
          label: 'Language',
          subtitle: 'English (US)',
          onPress: () => Alert.alert('Language', 'Language selection coming soon'),
        },
        {
          icon: Smartphone,
          label: 'Dark Mode',
          subtitle: darkMode ? 'Dark theme active' : 'Light theme active',
          hasSwitch: true,
          switchValue: darkMode,
          onSwitchChange: setDarkMode,
        },
      ],
    },
    {
      title: 'Data Management',
      items: [
        {
          icon: Download,
          label: 'Export Data',
          subtitle: 'Download all your documents',
          onPress: () => Alert.alert('Export', 'Data export coming soon'),
        },
        {
          icon: Trash2,
          label: 'Delete All Data',
          subtitle: 'Permanently remove all documents',
          onPress: () => Alert.alert(
            'Delete All Data',
            'This action cannot be undone. All your documents will be permanently deleted.',
            [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Delete', style: 'destructive' }
            ]
          ),
          danger: true,
        },
      ],
    },
    {
      title: 'Support',
      items: [
        {
          icon: HelpCircle,
          label: 'Help & FAQ',
          subtitle: 'Get help using the app',
          onPress: () => Alert.alert('Help', 'Help center coming soon'),
        },
        {
          icon: Info,
          label: 'About',
          subtitle: 'App version and information',
          onPress: () => Alert.alert(
            'About FARM STEW Scanner',
            'Version 1.0.0\n\nA document scanning app for NGO fieldwork.\n\nBuilt with React Native and Expo.'
          ),
        },
      ],
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Profile Card */}
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <User size={32} color="#28A745" />
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>NGO Worker</Text>
            <Text style={styles.profileEmail}>worker@farmstew.org</Text>
          </View>
          <TouchableOpacity style={styles.editProfile}>
            <Text style={styles.editProfileText}>Edit</Text>
          </TouchableOpacity>
        </View>

        {/* Settings Sections */}
        {settingsSections.map((section, sectionIndex) => (
          <View key={sectionIndex} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.sectionContent}>
              {section.items.map((item, itemIndex) => (
                <TouchableOpacity
                  key={itemIndex}
                  style={[
                    styles.settingItem,
                    itemIndex === section.items.length - 1 && styles.settingItemLast,
                    item.danger && styles.settingItemDanger,
                  ]}
                  onPress={item.onPress}
                  disabled={item.hasSwitch}
                >
                  <View style={styles.settingItemLeft}>
                    <View style={[
                      styles.settingIcon,
                      item.danger && styles.settingIconDanger
                    ]}>
                      <item.icon 
                        size={20} 
                        color={item.danger ? '#EF4444' : '#28A745'} 
                      />
                    </View>
                    <View style={styles.settingContent}>
                      <Text style={[
                        styles.settingLabel,
                        item.danger && styles.settingLabelDanger
                      ]}>
                        {item.label}
                      </Text>
                      <Text style={styles.settingSubtitle}>
                        {item.subtitle}
                      </Text>
                    </View>
                  </View>
                  
                  <View style={styles.settingItemRight}>
                    {item.hasSwitch ? (
                      <Switch
                        value={item.switchValue}
                        onValueChange={item.onSwitchChange}
                        trackColor={{ false: '#E2E8F0', true: '#28A745' }}
                        thumbColor={item.switchValue ? '#FFFFFF' : '#FFFFFF'}
                      />
                    ) : (
                      <ChevronRight size={16} color="#64748B" />
                    )}
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Storage Info */}
        <View style={styles.storageCard}>
          <Text style={styles.storageTitle}>Storage Usage</Text>
          <View style={styles.storageBar}>
            <View style={styles.storageUsed} />
          </View>
          <View style={styles.storageInfo}>
            <Text style={styles.storageText}>2.4 GB used of 5.0 GB</Text>
            <Text style={styles.storagePercentage}>48%</Text>
          </View>
        </View>

        {/* App Version */}
        <View style={styles.versionInfo}>
          <Text style={styles.versionText}>
            FARM STEW Scanner v1.0.0
          </Text>
          <Text style={styles.buildText}>
            Build 2024.01.15
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFBFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#0F1724',
  },
  scrollView: {
    flex: 1,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    margin: 20,
    padding: 20,
    borderRadius: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#F0FDF4',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#0F1724',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    color: '#64748B',
  },
  editProfile: {
    backgroundColor: '#28A745',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
  },
  editProfileText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748B',
    marginBottom: 12,
    marginHorizontal: 20,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  sectionContent: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F8FAFC',
  },
  settingItemLast: {
    borderBottomWidth: 0,
  },
  settingItemDanger: {
    backgroundColor: '#FEF2F2',
  },
  settingItemLeft: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F0FDF4',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  settingIconDanger: {
    backgroundColor: '#FEE2E2',
  },
  settingContent: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#0F1724',
    marginBottom: 2,
  },
  settingLabelDanger: {
    color: '#EF4444',
  },
  settingSubtitle: {
    fontSize: 12,
    color: '#64748B',
  },
  settingItemRight: {
    marginLeft: 16,
  },
  storageCard: {
    backgroundColor: '#FFFFFF',
    margin: 20,
    padding: 20,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  storageTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F1724',
    marginBottom: 12,
  },
  storageBar: {
    height: 8,
    backgroundColor: '#E2E8F0',
    borderRadius: 4,
    marginBottom: 12,
    overflow: 'hidden',
  },
  storageUsed: {
    height: '100%',
    width: '48%',
    backgroundColor: '#28A745',
    borderRadius: 4,
  },
  storageInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  storageText: {
    fontSize: 14,
    color: '#64748B',
  },
  storagePercentage: {
    fontSize: 14,
    color: '#28A745',
    fontWeight: '500',
  },
  versionInfo: {
    alignItems: 'center',
    paddingVertical: 20,
    marginBottom: 100,
  },
  versionText: {
    fontSize: 14,
    color: '#64748B',
    fontWeight: '500',
    marginBottom: 4,
  },
  buildText: {
    fontSize: 12,
    color: '#94A3B8',
  },
});