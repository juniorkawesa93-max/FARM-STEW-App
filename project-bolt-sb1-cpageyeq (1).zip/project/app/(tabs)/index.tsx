import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import {
  Plus,
  FileText,
  Folder,
  Clock,
  Star,
  Download,
  Share,
  MoreVertical,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);

  const recentDocuments = [
    {
      id: '1',
      name: 'Training Certificate_2024',
      type: 'PDF',
      date: '2024-01-15',
      pages: 2,
      size: '1.2 MB',
      thumbnail: '#FFD54F',
    },
    {
      id: '2',
      name: 'Field Report_Uganda',
      type: 'PDF', 
      date: '2024-01-14',
      pages: 5,
      size: '2.8 MB',
      thumbnail: '#06B6D4',
    },
    {
      id: '3',
      name: 'Receipt_Supplies',
      type: 'JPEG',
      date: '2024-01-13',
      pages: 1,
      size: '0.9 MB',
      thumbnail: '#28A745',
    },
  ];

  const folders = [
    { id: '1', name: 'Training Materials', count: 12, color: '#FFD54F' },
    { id: '2', name: 'Field Reports', count: 8, color: '#06B6D4' },
    { id: '3', name: 'Receipts', count: 15, color: '#28A745' },
    { id: '4', name: 'ID Documents', count: 6, color: '#EF4444' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good morning! 👋</Text>
            <Text style={styles.subtitle}>Ready to scan documents?</Text>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <View style={styles.notificationDot} />
          </TouchableOpacity>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActions}>
            <TouchableOpacity style={styles.quickAction}>
              <View style={[styles.quickActionIcon, { backgroundColor: '#28A745' }]}>
                <Plus size={24} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionText}>New Scan</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAction}>
              <View style={[styles.quickActionIcon, { backgroundColor: '#06B6D4' }]}>
                <FileText size={24} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionText}>Templates</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAction}>
              <View style={[styles.quickActionIcon, { backgroundColor: '#FFD54F' }]}>
                <Download size={24} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionText}>Import</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAction}>
              <View style={[styles.quickActionIcon, { backgroundColor: '#8B5CF6' }]}>
                <Share size={24} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionText}>Share</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Folders */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Folders</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.foldersContainer}
          >
            {folders.map((folder) => (
              <TouchableOpacity
                key={folder.id}
                style={styles.folderCard}
                onPress={() => setSelectedFolder(folder.id)}
              >
                <View style={[styles.folderIcon, { backgroundColor: folder.color }]}>
                  <Folder size={24} color="#FFFFFF" />
                </View>
                <Text style={styles.folderName} numberOfLines={1}>
                  {folder.name}
                </Text>
                <Text style={styles.folderCount}>{folder.count} documents</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Recent Documents */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Documents</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          {recentDocuments.map((doc) => (
            <TouchableOpacity key={doc.id} style={styles.documentCard}>
              <View style={[styles.documentThumbnail, { backgroundColor: doc.thumbnail }]}>
                <FileText size={20} color="#FFFFFF" />
              </View>
              <View style={styles.documentInfo}>
                <Text style={styles.documentName} numberOfLines={1}>
                  {doc.name}
                </Text>
                <View style={styles.documentMeta}>
                  <Clock size={12} color="#64748B" />
                  <Text style={styles.documentDate}>{doc.date}</Text>
                  <Text style={styles.documentPages}>{doc.pages} pages</Text>
                  <Text style={styles.documentSize}>{doc.size}</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.documentActions}>
                <MoreVertical size={16} color="#64748B" />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>

        {/* Statistics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>This Month</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>47</Text>
              <Text style={styles.statLabel}>Scanned</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>23</Text>
              <Text style={styles.statLabel}>Shared</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>12</Text>
              <Text style={styles.statLabel}>Archived</Text>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Floating Action Button */}
      <TouchableOpacity style={styles.fab}>
        <Plus size={28} color="#FFFFFF" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFBFC',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: '#0F1724',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#64748B',
  },
  notificationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  notificationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
    position: 'absolute',
    top: 8,
    right: 8,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#0F1724',
  },
  viewAllText: {
    fontSize: 14,
    color: '#28A745',
    fontWeight: '500',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  quickAction: {
    alignItems: 'center',
    flex: 1,
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  quickActionText: {
    fontSize: 12,
    color: '#0F1724',
    fontWeight: '500',
  },
  foldersContainer: {
    paddingRight: 20,
  },
  folderCard: {
    width: 120,
    marginRight: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  folderIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  folderName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0F1724',
    marginBottom: 4,
  },
  folderCount: {
    fontSize: 12,
    color: '#64748B',
  },
  documentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  documentThumbnail: {
    width: 48,
    height: 48,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F1724',
    marginBottom: 6,
  },
  documentMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  documentDate: {
    fontSize: 12,
    color: '#64748B',
  },
  documentPages: {
    fontSize: 12,
    color: '#64748B',
  },
  documentSize: {
    fontSize: 12,
    color: '#64748B',
  },
  documentActions: {
    padding: 8,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginHorizontal: 4,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: '700',
    color: '#28A745',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '500',
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 90,
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#28A745',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
});